Themify Base
========================================================

Themify Base is a simple minimal responsive theme which comes with many layout and customization options. You can customize every element of theme with live preview - site logo image, navigation menu, background, color, font selection with over 600+ Google Fonts, post styling, layout containers, etc.

Licenses
___________________________________________

CSS
----

- style.css
- media-queries.css
- style-editor.css
- All stylesheets in skins/
- themify/css/lightbox.css
- themify/css/themify-ui.css
- themify/css/themify-ui-rtl.css

Copyright: Themify
License:   GPLv3
Homepage:  http://themify.me

JavaScript
------------

- js/themify.script.js
- themify/js/lightbox.js
- themify/js/scripts.js
- themify/js/themify.customize.js
- themify/js/themify.gallery.js

Copyright: Themify
License:   GPLv3
Homepage:  http://themify.me

- js/respond.js

Copyright: Scott Jehl
License:   MIT/GPLv2
Homepage:  j.mp/respondjs

Images
------------

- All images

Copyright: Themify
License:   GPLv3
Homepage:  http://themify.me


Fonts
------------

- Font Awesome

Copyright: Dave Gandy
License:   SIL ()
Homepage:  http://fontawesome.github.com/Font-Awesome/
