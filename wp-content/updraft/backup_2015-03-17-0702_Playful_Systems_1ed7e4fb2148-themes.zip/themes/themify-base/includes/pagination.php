<?php
/**
 * Partial template for pagination
 */

themify_base_pagenav();