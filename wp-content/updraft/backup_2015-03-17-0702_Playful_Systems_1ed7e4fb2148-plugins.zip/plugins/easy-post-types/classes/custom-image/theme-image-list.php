<!-- <?php echo $values['value']['key']; ?>   -->
(<?php echo $values['value']; ?>) <?php _e('images'); ?>