<?php if ($values['extra']['show_label']=='yes') : ?>
    <span class="label"><?php echo $values['label']; ?></span>
<?php endif; ?>
<span class="field"><?php echo $values['value']; ?></span>