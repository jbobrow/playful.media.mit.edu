<table class="widefat tag fixed" cellspacing="0">
    <thead class="content-types-list">
      <tr>
        <th><?php _e('Add', 'cct'); ?></th>
        <th><?php _e('Title', 'cct'); ?></th>
        <th><?php _e('Type', 'cct'); ?></th>
        <th><?php _e('Status', 'cct'); ?></th>
        <th><?php _e('Date', 'cct'); ?></th>
      </tr>
    </thead>
    <tbody id="reference_fields_list" class="ui-sortable" >
        <?php include "list-row.php"; ?>
    </tbody>
  </table>
  <?php include "pagination.php"; ?>
