<div id="reference_searchlist-<?php echo $values['field_name']; ?>">
    <?php include "list-search-items.php"; ?>
</div>