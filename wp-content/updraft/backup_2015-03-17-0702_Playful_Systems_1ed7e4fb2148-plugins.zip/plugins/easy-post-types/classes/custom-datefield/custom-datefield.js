
jQuery(document).ready(function () {
    jQuery(".ct_datefield").datepicker();
});

