<span class="label">
    <?php echo $values['name']; ?>
</span>
<input class="ct_datefield" type="text" name="<?php echo $values['field_name']; ?>" value="<?php echo $values['value']; ?>"  />